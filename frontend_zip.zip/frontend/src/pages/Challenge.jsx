export default function Challenge() {
  return <h1 className="text-3xl font-bold text-center mt-10">Eco Quiz Page</h1>
}
